file = open('output','a')

file.write('hi')
file.close()